library(testthat)
library(bdc)

test_check("bdc")
